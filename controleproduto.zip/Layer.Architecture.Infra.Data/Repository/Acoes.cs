﻿using Layer.Architecture.Domain.Entities;
using Layer.Architecture.Infra.Data.Context;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Layer.Architecture.Infra.Data.Repository
{
    public class Acoes
    {
        public FiltroParaProdutos SelecionarProduto(int codigo)
        {
            using (var db = new ProdutoContext())
            {

                var produto = db.produtos.Where(w => w.CodigoProduto == codigo && w.SituacaoProduto == "ATIVO").First();
                var protudoParaRetorno = new FiltroParaProdutos()
                {
                    CodigoProduto = produto.CodigoProduto,
                    DescricaoProduto = produto.DescricaoProduto,
                    SituacaoProduto = produto.SituacaoProduto,
                    DataFabricacao = produto.DataFabricacao,
                    DataValidade = produto.DataValidade,
                    CnpjFornecedor = produto.CnpjFornecedor,
                    DescricaoFornecedor = produto.DescricaoFornecedor,
                    CodigoFornecedor = produto.CodigoFornecedor
                };
                return protudoParaRetorno;
            }
        }

        public List<FiltroParaProdutos> SelecionarTodosProdutos(FiltroParaProdutos dadosParaFiltragem)
        {
            using (var db = new ProdutoContext())
            {
                var listaDeProdutos = db.produtos.Where(w =>
                        w.CodigoProduto == dadosParaFiltragem.CodigoProduto ||
                        w.DescricaoProduto.Contains(dadosParaFiltragem.DescricaoProduto) ||
                        w.SituacaoProduto.Equals("ATIVO") ||
                        w.DataFabricacao.Equals(dadosParaFiltragem.DataFabricacao) ||
                        w.DataValidade.Equals(dadosParaFiltragem.DataValidade) ||
                        w.CodigoFornecedor.Equals(dadosParaFiltragem.CodigoFornecedor) ||
                        w.DescricaoFornecedor.Contains(dadosParaFiltragem.DescricaoFornecedor) ||
                        w.CnpjFornecedor.Contains(dadosParaFiltragem.CnpjFornecedor)
                        ).ToList();
                List<FiltroParaProdutos> retorno = new List<FiltroParaProdutos>();

                listaDeProdutos.ForEach(f =>
                {
                    retorno.Add(new FiltroParaProdutos
                    {
                        CodigoProduto = f.CodigoProduto,
                        DescricaoProduto = f.DescricaoProduto,
                        SituacaoProduto = f.SituacaoProduto,
                        DataFabricacao = f.DataFabricacao,
                        DataValidade = f.DataValidade,
                        CodigoFornecedor = f.CodigoFornecedor,
                        DescricaoFornecedor = f.DescricaoFornecedor,
                        CnpjFornecedor = f.CnpjFornecedor
                    });
                });

                return retorno;
            }
        }

        public bool InserirProduto(ProdutoAInserir produto)
        {
            using (var db = new ProdutoContext())
            {
                Produtos prod = new Produtos()
                {
                    DescricaoProduto = produto.DescricaoProduto,
                    SituacaoProduto = "ATIVO",
                    DataFabricacao = produto.DataFabricacao,
                    DataValidade = produto.DataValidade,
                    CodigoFornecedor = produto.CodigoFornecedor,
                    DescricaoFornecedor = produto.DescricaoFornecedor,
                    CnpjFornecedor = produto.CnpjFornecedor
                };
                db.produtos.Add(prod);
                db.SaveChanges();
                return true;
            }
        }

        public bool EditarProduto(FiltroParaProdutos dadosParaFiltragem)
        {
            using (var db = new ProdutoContext())
            {
                var listaDeProdutos = db.produtos.Where(w => w.CodigoProduto == dadosParaFiltragem.CodigoProduto).First();
                if ((!string.IsNullOrEmpty(dadosParaFiltragem.DescricaoProduto)))
                {
                    listaDeProdutos.DescricaoProduto = dadosParaFiltragem.DescricaoProduto; 
                }
                if (!string.IsNullOrEmpty(dadosParaFiltragem.SituacaoProduto))
                {
                    listaDeProdutos.SituacaoProduto = dadosParaFiltragem.SituacaoProduto; 
                }
                if (!(dadosParaFiltragem.DataFabricacao is null))
                {
                    listaDeProdutos.DataFabricacao = (DateTime)dadosParaFiltragem.DataFabricacao; 
                }
                if (!(dadosParaFiltragem.DataValidade is null))
                {
                    listaDeProdutos.DataValidade = (DateTime)dadosParaFiltragem.DataValidade; 
                }
                if (!string.IsNullOrEmpty(dadosParaFiltragem.CodigoFornecedor))
                {
                    listaDeProdutos.CodigoFornecedor = dadosParaFiltragem.CodigoFornecedor; 
                }
                if (!string.IsNullOrEmpty(dadosParaFiltragem.DescricaoFornecedor))
                {
                    listaDeProdutos.DescricaoFornecedor = dadosParaFiltragem.DescricaoFornecedor; 
                }
                if (!string.IsNullOrEmpty(dadosParaFiltragem.CnpjFornecedor))
                {
                    listaDeProdutos.CnpjFornecedor = dadosParaFiltragem.CnpjFornecedor; 
                }
                db.SaveChanges();
                return true;
            }
        }

        public bool ExcluirProduto(int codigo)
        {
            using (var db = new ProdutoContext())
            {
                var produto = db.produtos.Where(w => w.CodigoProduto == codigo).First();
                produto.SituacaoProduto = "INATIVO";
                db.SaveChanges();
                return true;
            }
        }
    }
}
