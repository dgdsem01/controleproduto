﻿namespace Layer.Architecture.Infra.Data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Produtos",
                c => new
                    {
                        CodigoProduto = c.Int(nullable: false, identity: true),
                        DescricaoProduto = c.String(nullable: false, maxLength: 300),
                        SituacaoProduto = c.String(nullable: false, maxLength: 7),
                        DataFabricacao = c.DateTime(nullable: false),
                        DataValidade = c.DateTime(nullable: false),
                        CodigoFornecedor = c.String(nullable: false),
                        DescricaoFornecedor = c.String(nullable: false, maxLength: 300),
                        CnpjFornecedor = c.String(nullable: false, maxLength: 18),
                    })
                .PrimaryKey(t => t.CodigoProduto);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Produtos");
        }
    }
}
