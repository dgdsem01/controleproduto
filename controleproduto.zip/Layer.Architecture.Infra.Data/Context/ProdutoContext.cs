﻿using Layer.Architecture.Domain.Entities;
using System.Data.Entity;

namespace Layer.Architecture.Infra.Data.Context
{
    public class ProdutoContext : DbContext
    {
        public DbSet<Produtos> produtos { get; set; }
    }
}
