﻿using Layer.Architecture.Domain.Entities;
using Layer.Architecture.Service.Services;
using Layer.testeAuto.Application.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ProdutoAInserir = Layer.Architecture.Domain.Entities.ProdutoAInserir;

namespace testeAuto.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AutoController : ControllerBase
    {
        private readonly ILogger<AutoController> _logger;

        public AutoController(ILogger<AutoController> logger)
        {
            _logger = logger;
        }

        [HttpGet, Route("manyproducts")]
        public IActionResult GetManyProducts([FromBody] Paginacao filtro)
        {
            BaseService service = new BaseService();
            var filtroParaProdutos = new FiltroParaProdutos()
            {
                CodigoProduto = filtro.filtro.CodigoProduto,
                DescricaoProduto = filtro.filtro.DescricaoProduto,
                DataFabricacao = filtro.filtro.DataFabricacao,
                DataValidade = filtro.filtro.DataValidade,
                CodigoFornecedor = filtro.filtro.CodigoFornecedor,
                DescricaoFornecedor = filtro.filtro.DescricaoFornecedor,
                CnpjFornecedor = filtro.filtro.CnpjFornecedor
            };


            return Ok(service.GetAllProdutos(filtroParaProdutos, filtro.pagina, filtro.quantidade));
        }

        [HttpGet("{codigo}")]
        public IActionResult GetOneProduct(int codigo)
        {
            BaseService service = new BaseService();

            return Ok(service.GetProduto(codigo));
        }

        [HttpPost]
        public IActionResult Post([FromBody] Layer.testeAuto.Application.Models.ProdutoAInserir produto)
        {
            BaseService service = new BaseService();

            ProdutoAInserir produtoParaInserir = new ProdutoAInserir()
            {
                DescricaoProduto = produto.DescricaoProduto,
                SituacaoProduto = "ATIVO",
                DataFabricacao = produto.DataFabricacao,
                DataValidade = produto.DataValidade,
                CodigoFornecedor = produto.CodigoFornecedor,
                DescricaoFornecedor = produto.DescricaoFornecedor,
                CnpjFornecedor = produto.CnpjFornecedor
            };

            return Ok(service.InsertProduto(produtoParaInserir));
        }

        [HttpPut]
        public IActionResult Put([FromBody] Filtro filtro)
        {
            BaseService service = new BaseService();
            var produtoParaAtualizacao = new FiltroParaProdutos()
            {
                CodigoProduto = filtro.CodigoProduto,
                DescricaoProduto = filtro.DescricaoProduto,
                DataFabricacao = filtro.DataFabricacao,
                DataValidade = filtro.DataValidade,
                CodigoFornecedor = filtro.CodigoFornecedor,
                DescricaoFornecedor = filtro.DescricaoFornecedor,
                CnpjFornecedor = filtro.CnpjFornecedor
            };


            return Ok(service.UpdateProduto(produtoParaAtualizacao));
        }

        [HttpDelete("{codigo}")]
        public IActionResult DeleteProduct(int codigo)
        {
            BaseService service = new BaseService();

            return Ok(service.DeleteProduto(codigo));
        }
    }
}
