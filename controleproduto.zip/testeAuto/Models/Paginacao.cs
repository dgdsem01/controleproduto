﻿namespace Layer.testeAuto.Application.Models
{
    public class Paginacao
    {
        public int pagina { get; set; }
        public int quantidade { get; set; }
        public Filtro filtro { get; set; }
    }
}
