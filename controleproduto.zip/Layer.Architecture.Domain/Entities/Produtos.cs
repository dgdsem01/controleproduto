﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Layer.Architecture.Domain.Entities
{
    public class Produtos
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key, Column(Order = 0)]
        public int CodigoProduto { get; set; }
        [Required(ErrorMessage = "O campo DescricaoProduto é obrigatório"), Column(Order = 1)]
        [StringLength(300)]
        public string DescricaoProduto { get; set; }
        [Required(ErrorMessage = "O campo SituacaoProduto é obrigatório"), Column(Order = 2)]
        [StringLength(7)]
        public string SituacaoProduto { get; set; }
        [Required(ErrorMessage = "O campo DataFabricacao é obrigatório"), Column(Order = 3)]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DataFabricacao { get; set; }
        [Required(ErrorMessage = "O campo DataValidade é obrigatório"), Column(Order = 4)]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DataValidade { get; set; }
        [Required(ErrorMessage = "O campo CodigoFornecedor é obrigatório"), Column(Order = 5)]
        public string CodigoFornecedor { get; set; }
        [Required(ErrorMessage = "O campo DescricaoFornecedor é obrigatório"), Column(Order = 7)]
        [StringLength(300)]
        public string DescricaoFornecedor { get; set; }
        [Required(ErrorMessage = "O campo CnpjFornecedor é obrigatório"), Column(Order = 8)]
        [StringLength(18)]
        public string CnpjFornecedor { get; set; }

    }
}
