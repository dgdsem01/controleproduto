﻿using System;

namespace Layer.Architecture.Domain.Entities
{
    public class FiltroParaProdutos
    {
        public int? CodigoProduto { get; set; }

        public string DescricaoProduto { get; set; }

        public string SituacaoProduto { get; set; }

        public DateTime? DataFabricacao { get; set; }

        public DateTime? DataValidade { get; set; }

        public string CodigoFornecedor { get; set; }

        public string DescricaoFornecedor { get; set; }

        public string CnpjFornecedor { get; set; }

    }
}
