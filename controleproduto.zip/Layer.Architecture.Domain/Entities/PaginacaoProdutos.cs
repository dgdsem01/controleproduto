﻿using Layer.Architecture.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Layer.Architecture.Domain.FilterEntities
{
    
    public class PaginacaoProdutos
    {
        public int pagina { get; set; }
        public int quantidadeProdutos { get; set; }
        public List<FiltroParaProdutos> listaDeProdutos { get; set; }
    }
}
