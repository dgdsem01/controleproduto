﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Layer.testeAuto.Domain.Entities
{
    public class Produtos
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key, Column(Order = 0)]
        public int CodigoProduto { get; set; }
        [Required, Column(Order = 1)]
        [StringLength(300)]
        public string DescricaoProduto { get; set; }
        [Required, Column(Order = 2)]
        [StringLength(7)]
        public string SituacaoProduto { get; set; }
        [Required, Column(Order = 3)]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DataFabricacao { get; set; }
        [Required, Column(Order = 4)]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DataValidade { get; set; }
        [Required, Column(Order = 5)]
        public int CodigoFornecedor { get; set; }
        [Required, Column(Order = 7)]
        [StringLength(300)]
        public string DescricaoFornecedor { get; set; }
        [Required, Column(Order = 7)]
        [StringLength(18)]
        public string CnpjFornecedor { get; set; }

    }
}
