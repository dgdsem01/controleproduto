﻿using Layer.testeAuto.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Layer.testeAuto.Domain.FilterEntities
{
    
    public class PaginacaoProdutos
    {
        public int pagina { get; set; }
        public int quantidadeProdutos { get { return 5; } }
        public List<Produtos> filtro { get; set; }
    }
}
