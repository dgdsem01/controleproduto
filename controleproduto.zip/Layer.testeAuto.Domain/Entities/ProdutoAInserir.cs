﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Layer.testeAuto.Domain.Entities
{
    public class ProdutoAInserir
    {
        public string DescricaoProduto { get; set; }

        public string SituacaoProduto { get; set; }

        public DateTime DataFabricacao { get; set; }

        public DateTime DataValidade { get; set; }

        public int CodigoFornecedor { get; set; }

        public string DescricaoFornecedor { get; set; }

        public string CnpjFornecedor { get; set; }

    }
}
