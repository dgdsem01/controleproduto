﻿using Layer.Architecture.Domain.Entities;
using Layer.Architecture.Domain.FilterEntities;
using Layer.Architecture.Infra.Data.Repository;
using Layer.Architecture.Service.utils;
using System.Linq;
using System.Text.Json;

namespace Layer.Architecture.Service.Services
{
    public class BaseService
    {
        public string GetProduto(int codigo)
        {
            Acoes acao = new Acoes();
            var retorno = JsonSerializer.Serialize(acao.SelecionarProduto(codigo));
            return string.IsNullOrEmpty(retorno.ToString()) ? "Nenhum registro foi encontrado" : retorno;
        }

        public string GetAllProdutos(FiltroParaProdutos filtro, int pagina, int quantidade)
        {
            Acoes acao = new Acoes();
            PaginacaoProdutos paginacaoProdutos = new PaginacaoProdutos();
            var registros = acao.SelecionarTodosProdutos(filtro);

            if (registros?.Count() <= 0)
            {
                return "Nenhum registro foi encontrado";
            }
            else
            {
                var registrosParaRetorno = registros.OrderBy(o => o.CodigoProduto)
                                            .Skip(quantidade * (pagina - 1))
                                            .Take(quantidade).ToList();
                paginacaoProdutos.listaDeProdutos = new System.Collections.Generic.List<FiltroParaProdutos>();
                paginacaoProdutos.listaDeProdutos.AddRange(registros);
                paginacaoProdutos.pagina = pagina;
                paginacaoProdutos.quantidadeProdutos = quantidade;

                var retorno = JsonSerializer.Serialize(paginacaoProdutos);

                return retorno;
            }
        }

        public string InsertProduto(ProdutoAInserir produto)
        {
            Acoes acao = new Acoes();

            if (produto.DataFabricacao >= produto.DataValidade)
            {
                return "A data de fabricação é igual ou maior que a data de validade";
            }

            if (string.IsNullOrEmpty(helpers.FormatCNPJ(produto.CnpjFornecedor)))
            {
                return $"O cnpj {produto.CnpjFornecedor} não é válido";
            }

            var inseriu = acao.InserirProduto(produto);

            if (inseriu)
            {
                return $"O produto {produto.DescricaoProduto}, foi inserido com sucesso";
            }
            else
            {
                return $"Falha ao inserir o produto {produto.DescricaoProduto}";
            }
        }

        public string UpdateProduto(FiltroParaProdutos produto)
        {
            Acoes acao = new Acoes();


            if (!(produto.DataFabricacao is null) && !(produto.DataValidade is null))
            {
                if (produto.DataFabricacao >= produto.DataValidade)
                {
                    return "A data de fabricação é igual ou maior que a data de validade";
                }
            }
            else
            {
                return "A data de fabricação e data de validade do produto podem estar nulas.";
            }

            if (!string.IsNullOrEmpty(produto.CnpjFornecedor))
            {
                if (string.IsNullOrEmpty(helpers.FormatCNPJ(produto.CnpjFornecedor)))
                {
                    return $"O cnpj {produto.CnpjFornecedor} não é válido";
                } 
            }

            var editou = acao.EditarProduto(produto);

            if (editou)
            {
                return $"O produto com o código {produto.CodigoProduto}, foi atualizado com sucesso";
            }
            else
            {
                return $"Falha ao atualizar o produto com o código {produto.CodigoProduto}";
            }
        }

        public string DeleteProduto(int codigo)
        {
            Acoes acao = new Acoes();
            var excluiu = acao.ExcluirProduto(codigo);

            if (excluiu)
            {
                return "Produto excluído com sucesso";
            }
            else
            {
                return "Falha ao excluir";
            }
        }
    }
}
