﻿namespace Layer.Architecture.Service.utils
{
    public class helpers
    {
        public static string FormatCNPJ(string CNPJ)
        {
            try
            {
                string text = SomenteNumeros(CNPJ);
                return text.Substring(0, 2) + "." + text.Substring(2, 3) + "." + text.Substring(5, 3) + "/" + text.Substring(8, 4) + "-" + text.Substring(12, 2);
            }
            catch 
            {
                return "";
            }
        }

        private static string SomenteNumeros(string texto)
        {
            if (string.IsNullOrEmpty(texto))
            {
                return "";
            }

            string text = "";
            for (int i = 0; i < texto.Length; i++)
            {
                if (char.IsDigit(texto[i]))
                {
                    text += texto[i];
                }
            }

            return text;
        }
    }
}
