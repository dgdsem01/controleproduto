﻿using Layer.testeAuto.Domain.Entities;
using Layer.testeAuto.Domain.FilterEntities;
using Layer.testeAuto.Infra.Data.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Layer.testeAuto.Infra.Data.Repository
{
    public class Acoes
    {
        public Produtos SelecionarProduto (int codigo)
        {
            using (var db = new ProdutoContext())
            {
                var produto = db.produtos.Where(w => w.CodigoProduto == codigo).First();
                return produto;
            }
        }

        public List<Produtos> SelecionarTodosProdutos(FiltroParaProdutos dadosParaFiltragem)
        {
            using (var db = new ProdutoContext())
            {
                var listaDeProdutos = db.produtos.Where(w =>
                        w.CodigoProduto == dadosParaFiltragem.CodigoProduto ||
                        w.DescricaoProduto.Contains(dadosParaFiltragem.DescricaoProduto) ||
                        w.SituacaoProduto.Equals(dadosParaFiltragem.SituacaoProduto) ||
                        w.DataFabricacao.Equals(dadosParaFiltragem.DataFabricacao) ||
                        w.DataValidade.Equals(dadosParaFiltragem.DataValidade) ||
                        w.CodigoFornecedor.Equals(dadosParaFiltragem.CodigoFornecedor) ||
                        w.DescricaoFornecedor.Contains(dadosParaFiltragem.DescricaoFornecedor) ||
                        w.CnpjFornecedor.Contains(dadosParaFiltragem.CnpjFornecedor)
                        ).ToList();
                return listaDeProdutos;
            }
        }

        public bool InserirProduto(ProdutoAInserir produto)
        {
            using (var db = new ProdutoContext())
            {
                Produtos prod = new Produtos()
                {
                    DescricaoProduto = produto.DescricaoProduto,
                    SituacaoProduto = produto.SituacaoProduto,
                    DataFabricacao = produto.DataFabricacao,
                    DataValidade = produto.DataValidade,
                    CodigoFornecedor = produto.CodigoFornecedor,
                    DescricaoFornecedor = produto.DescricaoFornecedor,
                    CnpjFornecedor = produto.CnpjFornecedor
                };
                db.produtos.Add(prod);
                db.SaveChanges();
                return true;
            }
        }

        public bool EditarProduto(FiltroParaProdutos dadosParaFiltragem)
        {
            using (var db = new ProdutoContext())
            {
                var listaDeProdutos = db.produtos.Where(w => w.CodigoProduto == dadosParaFiltragem.CodigoProduto).First();
                listaDeProdutos.DescricaoProduto = dadosParaFiltragem.DescricaoProduto;
                listaDeProdutos.SituacaoProduto = dadosParaFiltragem.SituacaoProduto;
                listaDeProdutos.DataFabricacao = (DateTime)dadosParaFiltragem.DataFabricacao;
                listaDeProdutos.DataValidade = (DateTime)dadosParaFiltragem.DataValidade;
                listaDeProdutos.CodigoFornecedor = (int)dadosParaFiltragem.CodigoFornecedor;
                listaDeProdutos.DescricaoFornecedor = dadosParaFiltragem.DescricaoFornecedor;
                listaDeProdutos.CnpjFornecedor = dadosParaFiltragem.CnpjFornecedor;
                db.SaveChanges();
                return true;
            }
        }

        public bool ExcluirProduto(int codigo)
        {
            using (var db = new ProdutoContext())
            {
                var produto = db.produtos.Where(w => w.CodigoProduto == codigo).First();
                produto.SituacaoProduto = "INATIVO";
                db.SaveChanges();
                return true;
            }
        }
    }
}
