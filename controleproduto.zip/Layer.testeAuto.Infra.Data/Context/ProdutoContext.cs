﻿using Layer.testeAuto.Domain.Entities;
using System.Data.Entity;

namespace Layer.testeAuto.Infra.Data.Context
{
    public class ProdutoContext : DbContext
    {
        public DbSet<Produtos> produtos { get; set; }
    }
}
